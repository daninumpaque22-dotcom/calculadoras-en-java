package calculadoraprog1;

public class Metods {
    private String chain;
    private double ans;
    private boolean ac, plus, minus, times, division, power, root, percentage, sin, cos, tan;
    
    public Metods(){
        chain="";
        ac=false;
        plus=false;
        minus=false;
        times=false;
        division=false;
        power=false;
        root=false;
        percentage=false;
        sin=false;
        cos=false;
        tan=false;
    }
    
    public String concatenation(String chain){
        this.chain=this.chain+chain;
        return this.chain;
    }
    public void ac(String chain){
        this.chain="";
        this.ac=false;
        this.plus=false;
        this.minus=false;
        this.times=false;
        this.division=false;
        this.power=false;
        this.root=false;
        this.percentage=false;
        this.sin=false;
        this.cos=false;
        this.tan=false;
    }
    public void plus(String chain){
        this.ans=Double.parseDouble(chain);
        plus=true;
        this.chain="";
    }
    public void minus(String chain){
        this.ans=Double.parseDouble(chain);
        minus=true;
        this.chain="";
    }
    public void times(String chain){
        this.ans=Double.parseDouble(chain);
        times=true;
        this.chain="";
    }
    public void division(String chain){
        this.ans=Double.parseDouble(chain);
        division=true;
        this.chain="";
    }
    public void power(String chain){
        this.ans=Double.parseDouble(chain);
        power=true;
        this.chain="";
    }
    public void root(String chain){
        this.ans=Double.parseDouble(chain);
        root=true;
        this.chain="";
    }
    public void percentage(String chain){
        this.ans=Double.parseDouble(chain);
        percentage=true;
        this.chain="";
    }
    public void sin(String chain){
        this.ans=Double.parseDouble(chain);
        sin=true;
        this.chain="";
    }
    public void cos(String chain){
        this.ans=Double.parseDouble(chain);
        cos=true;
        this.chain="";
    }
    public void tan(String chain){
        this.ans=Double.parseDouble(chain);
        tan=true;
        this.chain="";
    }
    
    public double ans(String num){
        if (plus==true){
            ans=ans+Double.parseDouble(num);
        }
        else if (minus==true){
            ans=ans-Double.parseDouble(num);
        }
        else if (times==true){
            ans=ans*Double.parseDouble(num);
        }
        else if (division==true){
            if(Double.parseDouble(num)==0){
                throw new ArithmeticException("Math Error");
            }
            ans=ans/Double.parseDouble(num);
        }
        else if (power==true){
            ans=Math.pow(ans,Double.parseDouble(num));
        }
        else if (root==true){
            ans=Math.pow(Double.parseDouble(num),1/ans);
        }
        else if (percentage==true){
            ans=ans*Double.parseDouble(num)/100;
        }
        else if (sin==true){
            double sin=Math.toRadians(ans);
            ans=Math.sin(sin);
        }
        else if (cos==true){
            double cos=Math.toRadians(ans);
            ans=Math.cos(cos);
        }
        else if (tan==true){
            double tan=Math.toRadians(ans);
            if(Math.cos(tan)<1e-10){
                throw new ArithmeticException("Math Error");
            }
            ans=Math.tan(tan);
        }
        
        return ans;
    }
}

